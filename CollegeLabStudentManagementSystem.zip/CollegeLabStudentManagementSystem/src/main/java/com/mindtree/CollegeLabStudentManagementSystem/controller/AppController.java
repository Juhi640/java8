package com.mindtree.CollegeLabStudentManagementSystem.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.CollegeLabStudentManagementSystem.dto.CollegeDto;
import com.mindtree.CollegeLabStudentManagementSystem.dto.LabDto;
import com.mindtree.CollegeLabStudentManagementSystem.dto.StudentDto;
import com.mindtree.CollegeLabStudentManagementSystem.service.CollegeLabStudentService;

@Controller
public class AppController {

	@Autowired
	CollegeLabStudentService collegelabstudentservice;
	
	@RequestMapping("/")
	public String login() {
		return "login";
	}
	
	@RequestMapping("/addcollegewithlabs")
	public String college() {
		return "addform";
	}
	
	@PostMapping(value = "/formadd")
	public String AddForm(CollegeDto collegedto,@RequestParam List<String> labName) {
		collegelabstudentservice.insertCollegeIntoDB(collegedto,labName);
		return "addform";
	}
	
	/*
	 * @RequestMapping("/addstudent") public String student() { return "searchpage";
	 * }
	 */
	
	@RequestMapping("/addstudent")
	public String addstudent() {
		return "formstudent";
	}
	
	@PostMapping(value = "/studentadd")
	public String AddStudent(StudentDto studentdto,@RequestParam List<String> labName) {
		collegelabstudentservice.insertStudentsIntoDB(studentdto, labName);
		return "formstudent";	
	}
	
	@RequestMapping("/booking")
	public String booked() {
	return "confirmbooking";
	}
	
	@RequestMapping("/viewlabs")
	public String getLabs(Model model) {
	Set<LabDto> labdtos=collegelabstudentservice.getAllLabsFromDB();
	model.addAttribute("labdtos",labdtos);
	return "viewtable";
	
	}
	
}
