package com.mindtree.CollegeLabStudentManagementSystem.dto;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class CollegeDto {

	private int collegeId;

	private String collegeName;

	private int capacity;

	private String location;

	@JsonIgnoreProperties("collegedto")
	private Set<LabDto> labsdto;

	public CollegeDto() {
		super();
	}

	public CollegeDto(int collegeId, String collegeName, int capacity, String location, Set<LabDto> labsdto) {
		super();
		this.collegeId = collegeId;
		this.collegeName = collegeName;
		this.capacity = capacity;
		this.location = location;
		this.labsdto = labsdto;
	}

	public int getCollegeId() {
		return collegeId;
	}

	public void setCollegeId(int collegeId) {
		this.collegeId = collegeId;
	}

	public String getCollegeName() {
		return collegeName;
	}

	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Set<LabDto> getLabsdto() {
		return labsdto;
	}

	public void setLabsdto(Set<LabDto> labsdto) {
		this.labsdto = labsdto;
	}

	@Override
	public String toString() {
		return "CollegeDto [collegeId=" + collegeId + ", collegeName=" + collegeName + ", capacity=" + capacity
				+ ", location=" + location + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + capacity;
		result = prime * result + collegeId;
		result = prime * result + ((collegeName == null) ? 0 : collegeName.hashCode());
		result = prime * result + ((location == null) ? 0 : location.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CollegeDto other = (CollegeDto) obj;
		if (capacity != other.capacity)
			return false;
		if (collegeId != other.collegeId)
			return false;
		if (collegeName == null) {
			if (other.collegeName != null)
				return false;
		} else if (!collegeName.equals(other.collegeName))
			return false;
		if (location == null) {
			if (other.location != null)
				return false;
		} else if (!location.equals(other.location))
			return false;
		return true;
	}

}
