package com.mindtree.CollegeLabStudentManagementSystem.dto;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class LabDto {

	private int labId;

	private String labName;

	@JsonIgnoreProperties("labsdto")
	private Set<StudentDto> studentsdto;

	@JsonIgnoreProperties("labsdto")
	private CollegeDto collegedto;

	public LabDto() {
		super();
	}

	public LabDto(int labId, String labName, Set<StudentDto> studentsdto, CollegeDto collegedto) {
		super();
		this.labId = labId;
		this.labName = labName;
		this.studentsdto = studentsdto;
		this.collegedto = collegedto;
	}

	public int getLabId() {
		return labId;
	}

	public void setLabId(int labId) {
		this.labId = labId;
	}

	public String getLabName() {
		return labName;
	}

	public void setLabName(String labName) {
		this.labName = labName;
	}

	public Set<StudentDto> getStudentsdto() {
		return studentsdto;
	}

	public void setStudentsdto(Set<StudentDto> studentsdto) {
		this.studentsdto = studentsdto;
	}

	public CollegeDto getCollegedto() {
		return collegedto;
	}

	public void setCollegedto(CollegeDto collegedto) {
		this.collegedto = collegedto;
	}

	@Override
	public String toString() {
		return "LabDto [labId=" + labId + ", labName=" + labName + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + labId;
		result = prime * result + ((labName == null) ? 0 : labName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LabDto other = (LabDto) obj;
		if (labId != other.labId)
			return false;
		if (labName == null) {
			if (other.labName != null)
				return false;
		} else if (!labName.equals(other.labName))
			return false;
		return true;
	}

}
