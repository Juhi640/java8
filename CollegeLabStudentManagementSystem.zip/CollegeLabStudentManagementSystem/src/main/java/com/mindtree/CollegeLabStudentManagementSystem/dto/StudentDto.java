package com.mindtree.CollegeLabStudentManagementSystem.dto;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class StudentDto {

	private int studentId;

	private String studentName;

	private String department;

	@JsonIgnoreProperties("studentsdto")
	private Set<LabDto> labsdto;

	public StudentDto() {
		super();
	}

	public StudentDto(int studentId, String studentName, String department, Set<LabDto> labsdto) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.department = department;
		this.labsdto = labsdto;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public Set<LabDto> getLabsdto() {
		return labsdto;
	}

	public void setLabsdto(Set<LabDto> labsdto) {
		this.labsdto = labsdto;
	}

	@Override
	public String toString() {
		return "StudentDto [studentId=" + studentId + ", studentName=" + studentName + ", department=" + department
				+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((department == null) ? 0 : department.hashCode());
		result = prime * result + studentId;
		result = prime * result + ((studentName == null) ? 0 : studentName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StudentDto other = (StudentDto) obj;
		if (department == null) {
			if (other.department != null)
				return false;
		} else if (!department.equals(other.department))
			return false;
		if (studentId != other.studentId)
			return false;
		if (studentName == null) {
			if (other.studentName != null)
				return false;
		} else if (!studentName.equals(other.studentName))
			return false;
		return true;
	}

}
