package com.mindtree.CollegeLabStudentManagementSystem.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

@Entity
public class Lab {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int labId;

	private String labName;

	@ManyToMany(cascade = { CascadeType.PERSIST, CascadeType.REFRESH }, mappedBy = "labs")
	private Set<Student> students;

	@ManyToOne(fetch = FetchType.LAZY)
	private College college;

	public Lab() {
		super();
	}

	public Lab(int labId, String labName, Set<Student> students, College college) {
		super();
		this.labId = labId;
		this.labName = labName;
		this.students = students;
		this.college = college;
	}

	public int getLabId() {
		return labId;
	}

	public void setLabId(int labId) {
		this.labId = labId;
	}

	public String getLabName() {
		return labName;
	}

	public void setLabName(String labName) {
		this.labName = labName;
	}

	public Set<Student> getStudents() {
		return students;
	}

	public void setStudents(Set<Student> students) {
		this.students = students;
	}

	public College getCollege() {
		return college;
	}

	public void setCollege(College college) {
		this.college = college;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + labId;
		result = prime * result + ((labName == null) ? 0 : labName.hashCode());

		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Lab other = (Lab) obj;
		if (labId != other.labId)
			return false;
		if (labName == null) {
			if (other.labName != null)
				return false;
		} else if (!labName.equals(other.labName))
			return false;

		return true;
	}

	@Override
	public String toString() {
		return "Lab [labId=" + labId + ", labName=" + labName + "]";
	}

}
