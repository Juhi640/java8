package com.mindtree.CollegeLabStudentManagementSystem.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.mindtree.CollegeLabStudentManagementSystem.entity.College;

@Repository
public interface CollegeRepository extends JpaRepositoryImplementation<College, Integer> {

}
