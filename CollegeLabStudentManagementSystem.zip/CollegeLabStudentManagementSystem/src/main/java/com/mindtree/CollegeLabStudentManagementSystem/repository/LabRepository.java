package com.mindtree.CollegeLabStudentManagementSystem.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.mindtree.CollegeLabStudentManagementSystem.entity.Lab;

@Repository
public interface LabRepository extends JpaRepositoryImplementation<Lab, Integer> {

	public Lab getByLabName(String labName1);
}
