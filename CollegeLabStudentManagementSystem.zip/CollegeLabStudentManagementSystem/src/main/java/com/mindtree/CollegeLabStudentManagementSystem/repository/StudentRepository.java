package com.mindtree.CollegeLabStudentManagementSystem.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.mindtree.CollegeLabStudentManagementSystem.entity.Student;

@Repository
public interface StudentRepository extends JpaRepositoryImplementation<Student, Integer> {

}
