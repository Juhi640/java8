package com.mindtree.CollegeLabStudentManagementSystem.service;

import java.util.List;
import java.util.Set;

import com.mindtree.CollegeLabStudentManagementSystem.dto.CollegeDto;
import com.mindtree.CollegeLabStudentManagementSystem.dto.LabDto;
import com.mindtree.CollegeLabStudentManagementSystem.dto.StudentDto;

public interface CollegeLabStudentService {

	public void insertCollegeIntoDB(CollegeDto collegedto, List<String> labName);

	public void insertStudentsIntoDB(StudentDto studentdto, List<String> labName);
	
	public Set<LabDto> getAllLabsFromDB();

}
