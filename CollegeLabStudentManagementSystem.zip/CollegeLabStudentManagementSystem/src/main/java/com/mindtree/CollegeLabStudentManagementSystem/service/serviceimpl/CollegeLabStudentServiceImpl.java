package com.mindtree.CollegeLabStudentManagementSystem.service.serviceimpl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.CollegeLabStudentManagementSystem.dto.CollegeDto;
import com.mindtree.CollegeLabStudentManagementSystem.dto.LabDto;
import com.mindtree.CollegeLabStudentManagementSystem.dto.StudentDto;
import com.mindtree.CollegeLabStudentManagementSystem.entity.College;
import com.mindtree.CollegeLabStudentManagementSystem.entity.Lab;
import com.mindtree.CollegeLabStudentManagementSystem.entity.Student;
import com.mindtree.CollegeLabStudentManagementSystem.repository.CollegeRepository;
import com.mindtree.CollegeLabStudentManagementSystem.repository.LabRepository;
import com.mindtree.CollegeLabStudentManagementSystem.repository.StudentRepository;
import com.mindtree.CollegeLabStudentManagementSystem.service.CollegeLabStudentService;

@Service
public class CollegeLabStudentServiceImpl implements CollegeLabStudentService {

	@Autowired
	CollegeRepository collegerepository;

	@Autowired
	LabRepository labrepository;

	@Autowired
	StudentRepository studentrepository;

	@Override
	public void insertCollegeIntoDB(CollegeDto collegedto, List<String> labName) {
		College college = new College();
		college.setCollegeId(collegedto.getCollegeId());
		college.setCollegeName(collegedto.getCollegeName());
		college.setCapacity(collegedto.getCapacity());
		college.setLocation(collegedto.getLocation());
		Set<Lab> labs = new HashSet<>();
		for (String labName1 : labName) {
			Lab lab = new Lab();
			lab = labrepository.getByLabName(labName1);
			lab.setCollege(college);
			labs.add(lab);

		}
		college.setLabs(labs);
		collegerepository.saveAndFlush(college);
	}

	@Override
	public void insertStudentsIntoDB(StudentDto studentdto, List<String> labName) {

		Student student = new Student();
		student.setStudentId(studentdto.getStudentId());
		student.setStudentName(studentdto.getStudentName());
		student.setDepartment(studentdto.getDepartment());
		Set<Student> students = new HashSet<>();
		students.add(student);
		Set<Lab> labs = new HashSet<>();
		for (String labName1 : labName) {
			Lab lab = new Lab();
			lab = labrepository.getByLabName(labName1);
			lab.setStudents(students);
			labs.add(lab);

		}
		student.setLabs(labs);
		studentrepository.save(student);
	}

	@Override
	public Set<LabDto> getAllLabsFromDB() {
		List<Lab> labs = labrepository.findAll();
		Set<LabDto> labsdto = new HashSet<>();
		for (Lab lab : labs) {
			LabDto labdto = new LabDto();
			labdto.setLabId(lab.getLabId());
			labdto.setLabName(lab.getLabName());
			labsdto.add(labdto);
		}
		return labsdto;

	}

}
