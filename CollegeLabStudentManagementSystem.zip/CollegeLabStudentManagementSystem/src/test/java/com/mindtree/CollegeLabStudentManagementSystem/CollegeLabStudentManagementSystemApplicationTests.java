package com.mindtree.CollegeLabStudentManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegeLabStudentManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
